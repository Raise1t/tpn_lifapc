enum Direction { NORD, SUD, EST, OUEST };
